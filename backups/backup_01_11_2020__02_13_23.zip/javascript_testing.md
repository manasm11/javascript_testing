1. Throw error: ```throw new Error("This is the error message !!!")```

## Setting up jasmin

1. Download Standalone zip and unzip it in a folder.
2. Create a source code (filename.js) file that will be tested in src folder.
3. Create a spec file (filenameSpec.js) file that will test the source code.
4. Add these files in SpecRunner.html
5. Then just run the SpecRunner.html in server.
